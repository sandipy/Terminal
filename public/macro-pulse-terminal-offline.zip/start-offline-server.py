#!/usr/bin/env python3
import http.server, socketserver, webbrowser, os
PORT = 8080
os.chdir(os.path.dirname(os.path.abspath(__file__)))
Handler = http.server.SimpleHTTPRequestHandler
print(f"\n==========================================")
print(f" MacroPulse Offline Terminal Started!")
print(f" URL: http://localhost:{PORT}")
print(f" Press Ctrl+C to stop.")
print(f"==========================================\n")
try:
    webbrowser.open(f"http://localhost:{PORT}")
except Exception:
    pass
with socketserver.TCPServer(("", PORT), Handler) as httpd:
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nTerminal stopped.")
