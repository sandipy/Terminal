=====================================================
MACROPULSE ECONOMIC CALENDAR & TRADING TERMINAL
OFFLINE STANDALONE PACKAGE
=====================================================
To launch offline:
1. Double-click "index.html" directly in your browser, OR
2. Double-click "start-terminal.bat" (Windows) or "python3 start-offline-server.py" (Mac/Linux)
