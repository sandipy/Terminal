=====================================================
MACROPULSE ECONOMIC CALENDAR & TRADING TERMINAL
OFFLINE STANDALONE PACKAGE
=====================================================
To run offline:
1. Double click "index.html" directly in your browser, OR
2. Double click "start-terminal.bat" (Windows) or run "python3 start-offline-server.py" (Mac/Linux)
